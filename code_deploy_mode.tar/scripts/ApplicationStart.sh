#!/bin/bash
docker run -p 5000:5000 --name fat_tiger -d 204065533127.dkr.ecr.ap-northeast-1.amazonaws.com/tiger:latest
